open_file = open(r"C:\Temp\phones.txt", "r")
s = open_file.readline()#open_file에서 10개의 문자를 입력받아 출력
for s in open_file:
    s = s.rstrip()
    print(s)
open_file.close()#출력후 닫기
