import os.path

if os.path.isfile(r"C:\Temp\phones2"):
    print("이미 존재합니다")
else:
    file_open = open(r"C:\Temp\phones2", "a")
    s = "김일수 101- 4258-5127"
    file_open.write(s)
    file_open.write("나현호 010-4258-5127")
    file_open.close()