"""
작성자:나현호
작성일"19.12.05
에제:
file에 사용자로 부터 이름과 전화번호를 받아서 phonese.text파일에 추가하라
lab 12_1을 실행하여 내용을 확인하라
"""
import os.path
if os.path.isfile(r"C:\Temp\phones"):
    print("이미 이름이 있습니다")
else:
    open_file = open(r"C:\Temp\phones","a")
    name = input()
    phone = input()
    open_file.write(name)
    open_file.write(phone)
    open_file.write("\n")
    open_file.close()
if os.path.isfile(r"C:\Temp\phones"):
    line = open_file.readline()
    print(line)