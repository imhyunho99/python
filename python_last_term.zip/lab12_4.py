"""
이미지 파일 열기
"""
infile = open("cat.JPG", "rb")
newfile = open("name.JPG", "wb")
while True:
    buffer = infile.read(1024)
    if not buffer:
        break
    newfile.write(buffer)
infile.close()
newfile.close()