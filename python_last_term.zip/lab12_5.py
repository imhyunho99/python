"""
movie.txt에 저장돤 내용을 읽어 movie 객체를 만든후 이를 movie.p에 bi 형태로 저장하라
"""
from pickle import *
from movie import *
infile = open("movie.txt", "r")
newfile = open("movie.p", "wb")
l = []
while True:
    string = infile.readline()
    m = string.split(", ")
    if not string:
        break
    if m[1] in "\n":
        m[1] = m[1][0:len(m[1]) - 2]
    n = Movie(m[0],m[1])
    l.append(n)
dump(l,newfile)
infile.close()
newfile.close()



newfile = open("movie.p","rb")
l = load(newfile)
for s in l:
    print(s)
newfile.close()