"""
작성자:나현호
작성일:19.10.24
문제: 사용자로부터 문자열을 입력받아서, 중간의 문자를 출력하라.
예)
king == in
bravo == a
"""
s = input()
k = len(s)//2
if(len(s)%2 == 0):
    s = s[k-1:k+1]
elif(len(s)%2 != 0):
    s = s[k:k+1]
print(s)