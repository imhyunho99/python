"""
작성자:나현호
작성일:19.10.24
문제: 사용자로부터 점수를 입력받아, 이를 리스트에 저장한 후, 평균과 입력된 정수를 출력하라
점수의 끝은 음수로 확인한다.
"""
l1 = []
sum = 0
while True:
    k = int(input())
    if k < 0:
        break
    l1.append(k)
for i in l1:
    sum = sum + i
k = round(sum/len(l1),2)
print(k)
print("입력된 정수:",l1)