"""
작성일:19.10.29
작성자:나현호
문제:
사용자로부터 한줄에 여러개의 숫자를 입력받는다.
숫자의 합을 출력하고
입력받은 숫자들을 역순으로 출력하라
"""
a = input().split()
sum = 0
for i in range(len(a)):
    a[i] = int(a[i])
    sum = sum + a[i]
a.sort()
a.reverse()
print(a)
print(sum)