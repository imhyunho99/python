"""
작성자:나현호
작성일:19.10.29
문제:deepcopy함수를 직접 정의하라
261pg문제를 작동해보라
"""
def deepcopy (scores):
    return list(scores)
scores = [10, 20, 30, 40, 50]
score = deepcopy(scores)
print(score)