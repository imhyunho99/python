"""
작성자:나현호
작성일19.10.31
묹제:한변의 길이가 50이하인 직각 삼각형의 세변의 길이를 출력하라
출력예)
[3,4,5],[5,12,13]
"""
l = []
for a in range(1, 51):
    for b in range(a, 51):
        for c in range(a, 51):
            if b**2 + c**2 == a**2:
                l.append([a,b,c])
for b in range(len(l)):
    print(l[b])