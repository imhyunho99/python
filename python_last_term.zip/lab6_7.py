"""
작성자:나현호
작성일:19.11.05
문제: 파일 만들고 블라와서 파일 리스트를 분류하기
C:\temp\data.txt 파일에 한 즐에 하나씩 과일이름을 5개 넣는다
사용자로부터 과일이름을 입력받아 해당 과일이 data파일에 있는 과일인지 여부를 출력한다
없는과일이면 "재고가 없습니다."를 출력한다
입력예)
사과
출력예)
사과는 재고가 없습니다.
"""
data = []
"""
파일의 path는 \\으로 한다
한글파일을 읽기 위해 인코딩은 utf-8로 한다
txt파일의 인코딩 방식도 
"""
f = open("C:\\Temp\\data.txt", "r", encoding="UTF-8-sig") #파일 가져오기
for line in f.readlines():
    data.append(line.strip())
s = input()
if s in data:
    print("재고가 있습니다")
else:
    print(s+"은(는) 재고가 없습니다.")
print(data)
