"""
작성자:나현호
작성일:19.11.05
문제:
각 층별로 3호실로 구성되어 있는 4층짜리 연립주택이 있다고 가정하자
각 층의 호실별로 전기사용량을 배정하고(임의의 값으로 채운다.)
각 층별 전기사용량의 합계, 최고값, 최저값, 전체세대의 전기사용량의 합계, 최고값, 최저값을 구하라.
이차원 배열을 사용한다.
출력)
1층: 최고=345 최저=242 합=1000
2층:
3층:
4층:
"""
apartment = [
    [10, 20, 30],
    [20, 30, 40],
    [30, 40, 50],
    [40, 50, 60]
            ]
aparta = 0
apartb = apartment[0][0]
apartall = apartment[0][0]
for i in range(len(apartment)):
    a = max(apartment[i])#각 층에서의 최대와 최소
    b = min(apartment[i])
    all = 0
    if aparta < a:#아파트 전체의 최대와 최소
        aparta = a
    if apartb > b:
        apartb = b
    for j in range(len(apartment[i])):
        all += apartment[i][j]
    print(i + 1,"층: 최고=",a ,"최저 = ", b, "합계 =" ,all)
    apartall += all
print("아파트 전체: 최고= ", aparta, "최저 =", apartb, "합계=",apartall)