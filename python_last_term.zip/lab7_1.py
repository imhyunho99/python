"""
작성자:나현호
작성일19.11.07
문제:
튜플을 매개변수로 받아서, 해당 튜플에 있는 최소값과 최대값을 반환하는 min_max함수를 정의한다.
프로그램에서는5개의 정수값을 가지는 튜플을 정의하고 min_max함수를 호출하여 결과를 출력하라
"""
def min_max(tup1):
    mini = min(tup1)
    maxi = max(tup1)
    return (mini,maxi)
tup1 = (12,14,15,7,-2)
tup2 = min_max(tup1)

print("최솟값:",tup2[0])
print("최댓값:",tup2[1])
