"""
작성자:나현호
작성일:19.11.07
문제:두명의 사용자로부터 좋아하는 과일을 입력받는다. 빈 칸을 띄어서 여러 개를 입력받을 수 있다
집합연산을 이용하여 두명이 모두 좋아하는 과일을 출력하라
"""
first = input().split()
second = input().split()
first = set(first)
second = set(second)
one = first - second
two = first - one
print(two)