"""
작성자:나현호
작성일:19.11.07
문제: 입력하는 문장의 단어의 계수를 출력하시오
"""
l = input().split()
for i in range(len(l)):
    l[i] = l[i].upper()
l = set(l)
print(l)
print(len(l))
