"""
작성자:나현호
작성일:19.11.12
문제: 학번과 점수를 dictionary를 이용하여 5개정도 정의한다.
사용자로부터 학번과 점수를 입력받아, 만약 기존 dictionary에 없다면 추가한다.
성적이 높은 순으로 출력하라
"""
scores = {"201914001": 9, "201914002": 7, "201914003": 10, "201914004": 1, "201914005": 5}
k = input().split()
name = k[0]
score = int(k[1])
if name not in scores and score not in scores:
    scores[name] = score
id_num = sorted(scores.items(), key=lambda x : x[1])
id_num.reverse()
for i in range(len(id_num)):
    print(id_num[i][0])