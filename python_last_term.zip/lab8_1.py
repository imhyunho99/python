"""
작성자:나현호
작성일:19.11.19
주제:class의 정의
"""
class counter:
    """
    갯수를 세는 클래스
    """
    def reset(self):
        self.count = 0 #member attribute의 정의, counter를 0으로 초기화
    def inc(self,i=1):
        self.count += i
        """
        count를 하나 중가
        self이외에 i가 매게변수로 추가되므로 
        :return: 없음
        """
    def current(self):
        return self.count
        """
        현재 self의 값을 반환
        :return: 현재 self의 값을 반환
        """
a = counter() #생성자를 이용하여 counter 객체 만들기,a에 배정
a.reset() #a가 self가 되어 method reset 이 호출된다
a.inc() #a를 증가시키기위해 inc를 호출
print('p 의 현재값',a.current())
a.inc()
print('p 의 현재값',a.current())