"""
8에서 dec메쏘드를 추가하시오 매개변수가 넘어오지 않으면 1을 감소시키고 넘어온다면 그 수만큼 감소시킨다
단 counter 값은 최소 1이다.
"""
"""
작성자:나현호
작성일:19.11.19
주제:class의 정의
"""
class counter:
    """
    갯수를 세는 클래스
    """
    def reset(self):
        self.count = 0 #member attribute의 정의, counter를 0으로 초기화
    def inc(self,i=1):
        self.count += i
        """
        count를 하나 중가
        self이외에 i가 매게변수로 추가되므로 
        :return: 없음
        """
    def dec(self, i=1):
        self.count -= i
        if self.count < 0:
            self.count = 0
    def current(self):#메써드 내에서 다른 메써드를 호출하는것도 가능하다
        return self.count

a = counter() #생성자를 이용하여 counter 객체 만들기,a에 배정
a.reset() #a가 self가 되어 method reset 이 호출된다
a.dec(100) #a를 증가시키기위해 inc를 호출
print('p 의 현재값',a.current())
a.dec(2)
print('p 의 현재값',a.current())