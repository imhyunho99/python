"""
작성자:나현호
작성일:19.11.19
문제:
직사각형의 가로(w)와 세로(h)가 멤버 어트리뷰트이다
init(i,j)로 초기화
area()넓이를 반환
lengh()둘레를 반환
print()가로와 세로를 출력
프로그램에서는
새로운 직사각형 객체를 생성하여 가로 3 세로 5로 설정하고 메쏘드를 이용하여 가로,세로, 높이를 구히여 출력
"""
class Sqr:
    def __init__(self,i,j):#__(---)__ >>>생성자 메쏘드, 초기화하는 메쏘드임, 생성자가 호출될때 같이 호출됨
        """

        :param i: w초기화용
        :param j: h초기화용
        :return: 없음
        """
        self.w = i
        self.h = j
    def area(self):
        """

        :return:넓이를 반환
        """
        return (self.w*self.h)
    def lengh(self):
        return (self.w*2 + self.h*2)
    def print(self):
        print("%d는 가로 %d는 세로 입니다"%(self.w, self.h))
s = Sqr()
s.init(3,5)
s.print()
print("%d는 넓이 입니다"%(s.area()))
print("%d는 둘레 입니다"%(s.lengh()))



