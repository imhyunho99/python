"""
작성자:나현호
작성일:19.11.21
문제:
원클레스를 정의한다. 반지름을 private instance variable로 설정한다. 반지름을 매개변수로받는 생성자를 생성한다.(반지름이 0보다 작으면 0으로)
setRadius와 getRadius를 정의한다. 넓이를 반환하는 getArea를 정의한다.
원의 반지름을 출력하는 print메쏘드를 정의한다.

프로그램에서는 r을 4로하는 원을 생성하고 원의 넓이를 출력한다
r을-5로 새로 설정하고 원을 출력한다
"""
class Circle:
    PI = 3.14#클래스 변수, 어느 메쏘드에도 속하지 않는다. 클래스 내에서 유일 classNmae.variableName
    def __init__(self,r):
        self.setRadius(r)
    def setRadius(self,r):
        if r > 0:
            self.__r = r
        else:
            self.__r = 0
    def getRadius(self):
        return self.__r
    def getLength(self):
        return self.__r*2*Circle.PI
    def getArea(self):
        return self.__r**2*Circle.PI
    def print(self):
        print(self.__r)
    def getPI():#클래스 메쏘드, 객체(메쏘드)와 관련이 없다.
        return Circle.PI
    def setPI(p):#클래스 메쏘드, 객체(메쏘드)와 관련이 없다.
        p = Circle.PI
c = Circle(4)
print(c.getArea())
c.setRadius(-5)
c.print()
print(Circle.getPI())
Circle.setPI(3.1415)
print(Circle.getPI())


