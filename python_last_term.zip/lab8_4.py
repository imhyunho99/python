"""
작성자:나현호
작성일19.11.21
문제:
Student 클래스를 정의한다. 학번의 최초값은 20000이다.
이름을 매개변수로 받아 학번과 이름을 설정한다. 한 학생이 생성하고 나면, 학번을 하나 증가시킨다(20000, 20001,,,)
학생의 정보를 출력하는 print함수가 있다(학번,이름)
학생의 수를 반환하는 클래스메쏘드 getCount가 있다.
프로그램에서는 세명의 학생을 생성하고, 학생의 정보를 출력한다.
학생의 수를  getCount함수를 호출하여 출력한다.
"""
class Student:
    id = 20000
    def __init__(self, Name = None):
        self.Name = Name
        self.ID = Student.id
        Student.id += 1
    def print(self):
        print("학생이름 %s 학번 %d"%(self.Name, self.ID))
    def getCount(self):
        return Student.id - 20000
for i in range(4):
    A = input()
    A = Student(A)
    A.print()
print(A.getCount())