"""
작성자:나현호
작성일:19.11.26
문제:
복소수를 나타내는 클래스 complex를 정의한다
두 실수를 매개변수로 받아 복소수를 정의하는 생성자를 정의한다.
실수부를 반환하는 getRealPart
허수부를 반환하는 getImagePart
복소수의 문자열을 반환하는 __str__을 정의한다.
켤레 복소수를 반환하는 pair를 정의한다.
두수의 합을 반환하는 __add__
두 수의 곱을 반환하는 __mul__을 정의한다.
프로그램에서는 3.5+4.6i, 5.4-7.2i를 초기값으로 가지는 복소수 c1, c2를 정의하여 출력한다
c1, c2의 켤레복소수, 두수의 합과 곱을 출력한다
"""
class Complex:
    def __init__(self, r, i):
        self.r = r
        self.i = i
    def getRealPart(self):
        return self.r
    def getImagePart(self):
        return self.i
    def __str__(self):
        return "(" + str(self.r) + ")" + "+" +"(" + str(self.i) + ")"
    def pair(self):#켤레복소수
        r = Complex(self.r,-self.i)
        return r
        return str(pair_r), '+', str(pair_i) + 'i'
    def __add__(self, other):#복소수의 합
        r = Complex(self.r + other.r, self.i + other.i)
        return r
    def __mul__(self, other):#복소수의
        r = Complex(self.r * other.r-(self.i * other.i),self.r*other.i + self.i*other.r)
        return r
c1 = Complex(3.5, 4.6)
c2 = Complex(5.4, -7.2)
c1.pair()
print(c1 + c2)