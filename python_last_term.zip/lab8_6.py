"""
작성자:나현호
작성일:19.11.26
문제:
좌표평면에서 점을 나타내는 Point 클래스를 정의한다.
x,y좌표를 받는 생성자
문자열을 반환하는 __str__
두 점사이의 거리를 반환하는 getDistance
x축의 대칭점을 반환하는 getXSymmetry
y축의 대칭점을 반환하는 getYSymmetry
원점의 대칭점을 반환하는 getOriginSysmmetry를 정의한다
프로그램에서
p1(3,5)
p2(-2,5) 의 두 점을 정의한다
p1 , x축대칭, y축대칭, 원점대칭, p2와의 거리를 출력한다.
"""
import math
class Point:
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def getDistance(self, other):
        print (math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2))
    def getXSysmmetry(self):
        x = Point(-self.x, self.y)
        return x
    def getYSysmmetry(self):
        x = Point(self.x, -self.y)
        return x
    def getOriginSysmmetry(self):
        x = Point(-self.x, -self.y)
        return x
    def __str__(self):
        return "(" + str(self.x) + "," + str(self.y) + ")"
p1 = Point(3,5)
p2 = Point(-2,5)
print(p1.getXSysmmetry())
p1.getDistance(p2)