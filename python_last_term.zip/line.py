def slope(x,y):
    a = (x[0]-y[0])
    b = (x[1]-y[1])
    sin = abs(b)/abs(a)
    return(sin)
def  y_intercept(x,y):
    a = (x[0] - y[0])
    b = (x[1] - y[1])
    sin = abs(b) / abs(a)
    yin = sin*(-x[0]) + y[0]
    return yin
